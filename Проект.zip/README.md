# ProjectCourseWorkPharmacy
Данная информационная система предназначена для автоматизации работы с данными сети аптек ООО "Аптека".

Система разработана на C# с использованием Windows Forms и взаимодействует с базой данных MS SQL.

#Исходный код
https://github.com/mkze13/ProjectCourseWorkPharmacy
